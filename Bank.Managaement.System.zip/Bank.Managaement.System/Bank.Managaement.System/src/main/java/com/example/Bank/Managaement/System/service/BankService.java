package com.example.Bank.Managaement.System.service;

import com.example.Bank.Managaement.System.model.*;

public interface BankService {
    AxisBank accountCreation(AxisBank axisBank);
    AxisBank profileUpdation(AxisBank axisBank);
    AxisBank amountDepoist(AmountDepoist amountDepoist);
    <T> Object amountWithdrwal(AmountWithdrwal withdrwalAmount);
    CurrencyRates getCurrencyRate();

    void countCreation1(Long account_number);
}
