package com.example.Bank.Managaement.System.model;

import lombok.Data;

@Data
public class Motd {
    private String msg;
    private String url;
}
