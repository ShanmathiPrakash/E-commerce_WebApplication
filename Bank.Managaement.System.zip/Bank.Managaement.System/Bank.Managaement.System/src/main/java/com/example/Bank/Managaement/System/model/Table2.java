package com.example.Bank.Managaement.System.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "Table2")

public class Table2 {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;
    @Column
    Long account_number;
    @Column
    String description;
    // ... other columns and relationships
}
