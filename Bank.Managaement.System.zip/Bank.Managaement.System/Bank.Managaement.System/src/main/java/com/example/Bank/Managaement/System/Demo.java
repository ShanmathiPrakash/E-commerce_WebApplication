package com.example.Bank.Managaement.System;
import lombok.Data;
import java.util.Map;

@Data
public class Demo {
    Motd2 motd2;
    boolean success;
    String base;
    String date;
    Map<String,Double> rates;
}
