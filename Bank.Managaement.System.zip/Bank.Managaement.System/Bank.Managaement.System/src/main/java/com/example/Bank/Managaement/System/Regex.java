package com.example.Bank.Managaement.System;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
    public static void main(String[] args) {
        String s= "Ram plays cricket often in his native";
        Pattern pattern= Pattern.compile("a");
        Matcher m=pattern.matcher(s);
        while (m.find())
        {
            System.out.println(m.group()+" starts "+ m.start() +" ends "+ m.end());
        }
    }
}
