package com.example.Bank.Managaement.System.model;

import lombok.Data;

@Data
public class AmountDepoist {
    private Long account_number;
    private Double depoist_amount;
}
