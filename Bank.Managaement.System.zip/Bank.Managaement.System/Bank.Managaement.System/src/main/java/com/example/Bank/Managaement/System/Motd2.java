package com.example.Bank.Managaement.System;

import lombok.Data;

@Data
public class Motd2 {
    String msg;
    String url;
}
