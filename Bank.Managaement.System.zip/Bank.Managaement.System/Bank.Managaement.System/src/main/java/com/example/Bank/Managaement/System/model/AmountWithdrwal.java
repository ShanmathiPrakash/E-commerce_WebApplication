package com.example.Bank.Managaement.System.model;

import lombok.Data;

@Data
public class AmountWithdrwal {
    private Long account_number;
    private Double withdrwal_amount;
}
